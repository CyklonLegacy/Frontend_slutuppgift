
fetch('/api/list/data.json')
.then(response=>{
   var data = response;
   return data.json();  //Parsing the data into json
})
.then(contents=>{
    console.log("Iterating through the 'result' array of objects to be displayed in table", contents);
      contents.lists.forEach(function(list){
        console.log(list);

        const element = document.createElement('h1')
        element.innerHTML = list.title;

        document.getElementById("id").appendChild(element);

          list.items.forEach(function(itemData) {
            console.log(itemData);

            const itemElement = document.createElement('article')
            itemElement.innerHTML = `
            <h2>${itemData.title}</h2>
            <p>${itemData.description}
            <img src="${itemData.image}">
            </p>

            <footer>
            <div>${itemData.price/100}€</div>
            <div onclick="ShowCar('${itemData.id}')"> Läs mer </div>
            </footer>
            `;

            document.getElementById("id").appendChild(itemElement);



        })
  })

})

window.ShowCar = function(id) {

  fetch(`/api/item/${id}.json`)
  .then(response=>{
     var data = response;
     return data.json();
  })
  .then(contents=>{
          console.log(contents);

          const car = document.createElement('article')


          car.innerHTML = `



          <div class="more">
          <div class="top">
          <h2>${contents.title}</h2>
          <img src="../resources/icons/close.svg" width="20" height="30" onclick="CloseCar()">
          </div>
          <div class="img">
          <img src="${contents.image}">
          </div>
          <div class="dots">
            <span class="red"></span>
            <span class="green"></span>
            <span class="blue"></span>
          </div>
          <div class="price">
            <div>${contents.price/100}€</div>
            <p>Lägg till i varukorg</p>
          </div>
          <div class="otherfooter">
            <div class="specs">
              <p>${contents.speed.acceleration}s</p>
              <p>${contents.speed.top}km/h</p>
              <p>${contents.range}km</p>
              </div>
          <div class="otherspecs">
            <p>0-100 km/h</p>
            <p>Topphastighet</p>
            <p>Räckvidd</p>
          </div>
          <footer>
          <div class="desc_full">
          <p>${contents.description_full}</p>
          </div>
          </footer>
          </div>
          </div>


          `;

          const overlay = document.querySelector(".overlay");

          overlay.innerHTML = "";
          overlay.appendChild(car);
          overlay.classList.add("view");



})

}

window.CloseCar = function() {

  document.querySelector(".overlay").classList.remove("view");
}
