# Slutuppgift

Skapa en webbplats där följande kriterier uppfylls:

1. **Använd HTML-element som grupperar och ger dokumentets innehåll betydelse**
    * Använd t.ex. main, article, section, header m.fl.

1. **Använd CSS för att skapa layouten**
    * Använd flexbox och grid.
    * Utgå från mobilskärmar, gör sedan anpassningar för större skärmar _(t.ex. med @media)_.

1. **Använd CSS för att förändra/formge HTML-elements default-styling**

1. **Använd JavaScript för att hämta JSON-data**
    * Använd fetch.

1. **Använd JavaScript för att skapa HTML-element utifrån JSON-data**

1. **Använd JavaScript för att lägga till/ändra/ta bort attribut/classer på HTML-element för att göra en visuell ändring av element(et/en) med CSS**

Om något är oklart eller du kör fast, maila: **johan@westling.ax**.

<br id="alternativ-1">

## Alternativ 1

Gör en webbplats som uppfyller ovanstående krav utifrån design-specifikationen i bilderna:
* ```material/design-index.png```
* ```material/design-scrolled.png```
* ```material/design-car-expanded.png```.

<span id="alternativ-2">

## Alternativ 2

Gör en webbplats som uppfyller ovanstående krav med eget innehåll och/eller design.

<br id="api">

## API

I vanliga fall skulle ett API varit en webserver som ger ut JSON-data (kanske baserat på en databas). För att underlätta slutuppgiften något tillhandahålls ett "fake" API i from av statiska JSON-filer som du hittar i mappen ```dist/api/```.

**Hämta data från localhost-serverns API med följande URLs (endpoints):**
```bash
/api/list/data.json         # Datan för att rendera material/design-index.png.

/api/item/***.json          # Datan för att rendera material/design-car-expanded.png.
                            # Ersätt *** med id-propertyn du får i /api/list/data.json.
```

_Göra du [Alternativ 2](#alternativ-2) rekommenderas att du placerar JSON-filer med dummy-data i ```dist/api/``` före inlämning (om inte API:et är tillgängligt från internet)._


<br id="resurser">

## Resurser

Bilder, ikoner, logotypen (och eventuella andra resurser) hittar du i mappen ```dist/resources/```.

_Göra du [Alternativ 2](#alternativ-2) rekommenderas att du placerar dina resurser i ```dist/resources/```._

**För att referera till en resurs i JavaScript använder du följande URL:**
```bash
/resources/***              # Ersätt *** med resterande del av sökvägen till filen.
```

**För att referera till en resurs i HTML-filer i ```src```-mappen använder du följande:**
```bash
../dist/resources/***       # Ersätt *** med resterande del av sökvägen till filen.
```

Orsaken till att referenserna är olika beroende på var de används är på grund av våran bundler (Parcel).

Refererar vi till en bild, CSS-fil eller JavaScript-fil i t.ex. ```src/index.html``` försöker Parcel samla ihop alla resurser som hittas i ```src/index.html``` för att sedan paketera dessa och publicera dem i ```dist```-mappen.

Då våra bilderna redan är placerade ```dist/references```-mappen hittar Parcel således inte filerna om vi inte lägger till ```../dist``` i början referensen.

Däremot då vi skapar en referens i JavaScript (t.ex. i en template literal) så läses denna referens inte av Parcel, utan det är webbläsaren som försöker hitta resursen utgående från ```dist```-mappen, och därmed behöver vi inte referera till ```../dist``` utan inleder våra URL:s med enbart ```/```.


<br>

---

<br id="installation">

## Installation

För att göra slutuppgiften och paketera den för inlämning behöver du Node.js installerat på din dator, kontrollera detta med följande steg:

1. Öppna terminalen.
1. Skriv:
    ```bash
    node -v
    ```

    Skrivs ett versionnummer som börjar på v10 eller högre kan du fortsätta till [Installation Localhost]("#installation-localhost"), om inte se [Installation Node.js](#installation-nodejs).

<br id="installation-localhost">

### Installation - Localhost

1. Öppna terminalen.

1. Förflytta dig till mappen där du har slutuppgiften:
    ```bash
    cd $HOME/frontend-2019/slutuppgift
    ```

1. Installera localhost:
    ```bash
    npm install
    ```

1. Starta localhost servern:
    ```bash
    npm start
    ```

1. Öppna webbläsaren och gå till URL:en som visas i terminalen (vanligtvis ```http://localhost:1234```).

<br id="installation-nodejs">

### Installation - Node.js

1. Gå till: [https://nodejs.org/en/download/](https://nodejs.org/en/download/)

1. Välj det som passar din dator bäst, är du osäker fråga på mailen: johan@westling.ax.

<br>

---

<br id="inlamning">

## Inlämning

När du är redo för inlämning gör du följande:

1. Öppna terminalen.

1. Förflytta dig till mappen där du har slutuppgiften:
    ```bash
    cd $HOME/frontend-2019/slutuppgift
    ```

1. Exportera din slutuppgift:
    ```bash
    npm run export
    ```

1. Lämna in din ```ha-frontend-2019-slutuppgift-1.0.0.tgz``` (som nu finns i slutuppgiftsmappen) på Moodle.